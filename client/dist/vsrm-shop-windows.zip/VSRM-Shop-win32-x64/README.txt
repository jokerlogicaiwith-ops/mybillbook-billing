==============================================
VSRM SHOP - BILLING & ACCOUNTING (WINDOWS EDITION)
Business Profile: APOORV Enterprise
Contact: +91 8130140936
Location: Station Road, Samastipur, Bihar
==============================================

HOW TO RUN ON WINDOWS:
1. Double-click on "Create-Desktop-Shortcut.bat" (recommended).
   It will create a desktop shortcut with the Golden Logo and launch the app!
2. OR directly double-click on "VSRM-Shop.exe" or "Start-VSRM-Shop.bat".

FEATURES:
- Lifetime Active Billing & GST Invoicing
- Fast POS & Thermal / A4 Print (Ctrl + P)
- Full-Screen Billing Counter Mode (F11)
- Automatic Data Sync with https://vsrm.shop
- Auto-reconnect & offline protection
==============================================
