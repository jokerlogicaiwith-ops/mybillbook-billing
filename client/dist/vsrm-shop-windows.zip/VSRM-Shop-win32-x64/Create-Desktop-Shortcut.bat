@echo off
title VSRM Shop - Desktop Shortcut Installer
echo ========================================================
echo   VSRM Shop - Creating Desktop & Start Menu Shortcut
echo ========================================================
echo.

set SCRIPT="%TEMP%\vsrm_shortcut_installer_%RANDOM%.vbs"

echo Set oWS = WScript.CreateObject("WScript.Shell") > %SCRIPT%
echo sDesktop = oWS.SpecialFolders("Desktop") >> %SCRIPT%
echo sPrograms = oWS.SpecialFolders("Programs") >> %SCRIPT%
echo. >> %SCRIPT%
echo ' 1. Create Desktop Shortcut >> %SCRIPT%
echo Set oLink = oWS.CreateShortcut(sDesktop ^& "\VSRM Shop Billing.lnk") >> %SCRIPT%
echo oLink.TargetPath = "%~dp0VSRM-Shop.exe" >> %SCRIPT%
echo oLink.WorkingDirectory = "%~dp0" >> %SCRIPT%
echo oLink.Description = "VSRM Shop - Billing & Accounting" >> %SCRIPT%
echo oLink.IconLocation = "%~dp0assets\app.ico,0" >> %SCRIPT%
echo oLink.Save >> %SCRIPT%
echo. >> %SCRIPT%
echo ' 2. Create Start Menu Shortcut >> %SCRIPT%
echo Set oStartLink = oWS.CreateShortcut(sPrograms ^& "\VSRM Shop Billing.lnk") >> %SCRIPT%
echo oStartLink.TargetPath = "%~dp0VSRM-Shop.exe" >> %SCRIPT%
echo oStartLink.WorkingDirectory = "%~dp0" >> %SCRIPT%
echo oStartLink.Description = "VSRM Shop - Billing & Accounting" >> %SCRIPT%
echo oStartLink.IconLocation = "%~dp0assets\app.ico,0" >> %SCRIPT%
echo oStartLink.Save >> %SCRIPT%

cscript /nologo %SCRIPT%
if exist %SCRIPT% del %SCRIPT%

echo [SUCCESS] VSRM Shop Desktop Shortcut created on your Desktop!
echo [SUCCESS] Golden Icon attached successfully!
echo [SUCCESS] Start Menu shortcut created!
echo.
echo Launching VSRM Shop now...
start "" "%~dp0VSRM-Shop.exe"
exit
