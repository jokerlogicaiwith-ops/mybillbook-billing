@echo off
echo Creating Desktop Shortcut for VSRM Shop...
set SCRIPT="%TEMP%\%RANDOM%-%RANDOM%_shortcut.vbs"
echo Set oWS = WScript.CreateObject("WScript.Shell") >> %SCRIPT%
echo sLinkFile = oWS.SpecialFolders("Desktop") ^& "\VSRM Shop Billing.lnk" >> %SCRIPT%
echo Set oLink = oWS.CreateShortcut(sLinkFile) >> %SCRIPT%
echo oLink.TargetPath = "%~dp0VSRM-Shop.exe" >> %SCRIPT%
echo oLink.WorkingDirectory = "%~dp0" >> %SCRIPT%
echo oLink.Description = "VSRM Shop - Billing & Accounting" >> %SCRIPT%
echo oLink.IconLocation = "%~dp0assetspp.ico" >> %SCRIPT%
echo oLink.Save >> %SCRIPT%
cscript /nologo %SCRIPT%
del %SCRIPT%
echo Desktop shortcut created successfully with Golden Icon!
echo Starting VSRM Shop...
start "" "%~dp0VSRM-Shop.exe"
