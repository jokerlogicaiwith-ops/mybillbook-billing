@echo off
title VSRM Shop - Billing & Accounting
start "" "%~dp0VSRM-Shop.exe"
