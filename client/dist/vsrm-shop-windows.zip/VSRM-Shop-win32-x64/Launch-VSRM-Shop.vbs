Set WshShell = CreateObject("WScript.Shell")
WshShell.Run chr(34) & WshShell.CurrentDirectory & "\VSRM-Shop.exe" & chr(34), 0
Set WshShell = Nothing
