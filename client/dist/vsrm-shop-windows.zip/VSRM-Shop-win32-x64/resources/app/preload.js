const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronDesktop', {
  platform: process.platform,
  isElectron: true,
  print: () => ipcRenderer.send('trigger-print')
});
