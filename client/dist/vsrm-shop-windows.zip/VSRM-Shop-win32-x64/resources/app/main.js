const { app, BrowserWindow, Menu, shell, ipcMain, dialog } = require('electron');
const path = require('path');

const LIVE_URL = 'https://vsrm.shop/';
let mainWindow = null;

// Enforce single instance lock
const gotTheLock = app.requestSingleInstanceLock();
if (!gotTheLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });

  app.whenReady().then(createWindow);
}

function createWindow() {
  const iconPath = path.join(__dirname, 'assets', process.platform === 'win32' ? 'app.ico' : 'app.png');

  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 1024,
    minHeight: 640,
    title: 'VSRM Shop - Billing & Accounting',
    icon: iconPath,
    backgroundColor: '#0f172a',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
      spellcheck: false
    }
  });

  setupMenu();

  // Load the cloud billing app
  mainWindow.loadURL(LIVE_URL);

  // Fallback to offline page if load fails
  mainWindow.webContents.on('did-fail-load', (event, errorCode, errorDescription, validatedURL) => {
    if (errorCode === -105 || errorCode === -106 || errorCode === -102 || errorCode === -118 || errorCode === -2) {
      mainWindow.loadFile(path.join(__dirname, 'offline.html'));
    }
  });

  // Handle new window popups / external links
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('https://api.whatsapp.com') || url.startsWith('https://wa.me') || url.includes('payment') || url.startsWith('mailto:')) {
      shell.openExternal(url);
      return { action: 'deny' };
    }
    return { action: 'allow' };
  });

  mainWindow.on('page-title-updated', (e) => {
    e.preventDefault();
    mainWindow.setTitle('VSRM Shop - Billing & Accounting (APOORV)');
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

// IPC listener for direct print requests
ipcMain.on('trigger-print', (event) => {
  if (mainWindow) {
    mainWindow.webContents.print({ silent: false, printBackground: true });
  }
});

function setupMenu() {
  const template = [
    {
      label: 'File',
      submenu: [
        {
          label: 'Print Bill / Receipt',
          accelerator: 'CmdOrCtrl+P',
          click: () => {
            if (mainWindow) {
              mainWindow.webContents.print({ silent: false, printBackground: true });
            }
          }
        },
        { type: 'separator' },
        { role: 'quit', label: 'Exit VSRM Shop' }
      ]
    },
    {
      label: 'View',
      submenu: [
        { role: 'reload', label: 'Refresh (ताज़ा करें)' },
        { role: 'forceReload', label: 'Force Reload (Clear Cache)' },
        { type: 'separator' },
        { role: 'resetZoom', label: 'Actual Size' },
        { role: 'zoomIn', label: 'Zoom In' },
        { role: 'zoomOut', label: 'Zoom Out' },
        { type: 'separator' },
        { role: 'togglefullscreen', label: 'Billing Counter Full Screen (F11)' }
      ]
    },
    {
      label: 'Billing Tools',
      submenu: [
        {
          label: 'Open Web Dashboard in Browser',
          click: () => shell.openExternal(LIVE_URL)
        },
        {
          label: 'Samastipur Business Support (WhatsApp)',
          click: () => shell.openExternal('https://wa.me/918130140936?text=Hello%20VSRM%20Shop%20Support')
        }
      ]
    },
    {
      label: 'Help',
      submenu: [
        {
          label: 'About VSRM Shop Desktop',
          click: () => {
            dialog.showMessageBox(mainWindow, {
              type: 'info',
              title: 'About VSRM Shop',
              message: 'VSRM Shop - Billing & Accounting Desktop Edition',
              detail: 'Business: APOORV Enterprise\nPhone: +91 8130140936\nLocation: Samastipur, Bihar\nPlatform: Windows Desktop Client v1.0',
              icon: path.join(__dirname, 'assets', 'app.png')
            });
          }
        }
      ]
    }
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
}

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (mainWindow === null) {
    createWindow();
  }
});
