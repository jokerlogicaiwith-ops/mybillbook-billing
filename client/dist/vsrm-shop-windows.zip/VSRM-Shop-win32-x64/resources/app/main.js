const { app, BrowserWindow, Menu, shell, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const { exec } = require('child_process');

const LIVE_URL = 'https://vsrm.shop/';
let mainWindow = null;

function ensureDesktopShortcut(notifyIfManual = false) {
  if (process.platform !== 'win32') return;
  try {
    const desktopDir = app.getPath('desktop');
    const shortcutPath = path.join(desktopDir, 'VSRM Shop Billing.lnk');
    const exePath = process.execPath;
    const baseDir = path.dirname(exePath);
    const iconPath = path.join(baseDir, 'assets', 'app.ico');

    if (!notifyIfManual && fs.existsSync(shortcutPath)) {
      return;
    }

    const vbsCode = `
Set oWS = WScript.CreateObject("WScript.Shell")
sDesktop = oWS.SpecialFolders("Desktop")
sPrograms = oWS.SpecialFolders("Programs")
Set oLink = oWS.CreateShortcut(sDesktop & "\\VSRM Shop Billing.lnk")
oLink.TargetPath = "${exePath.replace(/\\/g, '\\\\')}"
oLink.WorkingDirectory = "${baseDir.replace(/\\/g, '\\\\')}"
oLink.Description = "VSRM Shop - Billing & Accounting"
oLink.IconLocation = "${iconPath.replace(/\\/g, '\\\\')},0"
oLink.Save
Set oStart = oWS.CreateShortcut(sPrograms & "\\VSRM Shop Billing.lnk")
oStart.TargetPath = "${exePath.replace(/\\/g, '\\\\')}"
oStart.WorkingDirectory = "${baseDir.replace(/\\/g, '\\\\')}"
oStart.Description = "VSRM Shop - Billing & Accounting"
oStart.IconLocation = "${iconPath.replace(/\\/g, '\\\\')},0"
oStart.Save
`.trim();

    const tempVbs = path.join(app.getPath('temp'), `vsrm_sc_${Date.now()}.vbs`);
    fs.writeFileSync(tempVbs, vbsCode);
    exec(`cscript //nologo "${tempVbs}"`, (err) => {
      try { if (fs.existsSync(tempVbs)) fs.unlinkSync(tempVbs); } catch (e) {}
      if (notifyIfManual && mainWindow) {
        dialog.showMessageBox(mainWindow, {
          type: 'info',
          title: 'Desktop Shortcut Created',
          message: 'VSRM Shop का शॉर्टकट आइकन आपके कंप्यूटर के Desktop पर सफलतापूर्वक बना दिया गया है!',
          detail: 'अब आप सीधे Desktop से VSRM Shop को कभी भी 1-क्लिक में खोल सकते हैं।',
        });
      }
    });
  } catch (err) {
    console.error('Error creating desktop shortcut:', err);
  }
}

// Enforce single instance lock
const gotTheLock = app.requestSingleInstanceLock();
if (!gotTheLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });

  app.whenReady().then(() => {
    createWindow();
    setTimeout(() => {
      ensureDesktopShortcut(false);
    }, 2000);
  });
}

function createWindow() {
  const iconPath = path.join(__dirname, 'assets', process.platform === 'win32' ? 'app.ico' : 'app.png');

  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 1024,
    minHeight: 640,
    title: 'VSRM Shop - Billing & Accounting',
    icon: iconPath,
    backgroundColor: '#0f172a',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
      spellcheck: false
    }
  });

  setupMenu();

  // Load the cloud billing app
  mainWindow.loadURL(LIVE_URL);

  // Fallback to offline page if load fails
  mainWindow.webContents.on('did-fail-load', (event, errorCode, errorDescription, validatedURL) => {
    if (errorCode === -105 || errorCode === -106 || errorCode === -102 || errorCode === -118 || errorCode === -2) {
      mainWindow.loadFile(path.join(__dirname, 'offline.html'));
    }
  });

  // Handle new window popups / external links
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('https://api.whatsapp.com') || url.startsWith('https://wa.me') || url.includes('payment') || url.startsWith('mailto:')) {
      shell.openExternal(url);
      return { action: 'deny' };
    }
    return { action: 'allow' };
  });

  mainWindow.on('page-title-updated', (e) => {
    e.preventDefault();
    mainWindow.setTitle('VSRM Shop - Billing & Accounting (APOORV)');
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

// IPC listener for direct print requests
ipcMain.on('trigger-print', (event) => {
  if (mainWindow) {
    mainWindow.webContents.print({ silent: false, printBackground: true });
  }
});

function setupMenu() {
  const template = [
    {
      label: 'File',
      submenu: [
        {
          label: 'Print Bill / Receipt',
          accelerator: 'CmdOrCtrl+P',
          click: () => {
            if (mainWindow) {
              mainWindow.webContents.print({ silent: false, printBackground: true });
            }
          }
        },
        { type: 'separator' },
        { role: 'quit', label: 'Exit VSRM Shop' }
      ]
    },
    {
      label: 'View',
      submenu: [
        { role: 'reload', label: 'Refresh (ताज़ा करें)' },
        { role: 'forceReload', label: 'Force Reload (Clear Cache)' },
        { type: 'separator' },
        { role: 'resetZoom', label: 'Actual Size' },
        { role: 'zoomIn', label: 'Zoom In' },
        { role: 'zoomOut', label: 'Zoom Out' },
        { type: 'separator' },
        { role: 'togglefullscreen', label: 'Billing Counter Full Screen (F11)' }
      ]
    },
    {
      label: 'Billing Tools',
      submenu: [
        {
          label: 'Create / Repair Desktop Shortcut (डेस्कटॉप पर शॉर्टकट बनाएं)',
          click: () => ensureDesktopShortcut(true)
        },
        { type: 'separator' },
        {
          label: 'Open Web Dashboard in Browser',
          click: () => shell.openExternal(LIVE_URL)
        },
        {
          label: 'Samastipur Business Support (WhatsApp)',
          click: () => shell.openExternal('https://wa.me/918130140936?text=Hello%20VSRM%20Shop%20Support')
        }
      ]
    },
    {
      label: 'Help',
      submenu: [
        {
          label: 'About VSRM Shop Desktop',
          click: () => {
            dialog.showMessageBox(mainWindow, {
              type: 'info',
              title: 'About VSRM Shop',
              message: 'VSRM Shop - Billing & Accounting Desktop Edition',
              detail: 'Business: APOORV Enterprise\nPhone: +91 8130140936\nLocation: Samastipur, Bihar\nPlatform: Windows Desktop Client v1.0',
              icon: path.join(__dirname, 'assets', 'app.png')
            });
          }
        }
      ]
    }
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
}

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (mainWindow === null) {
    createWindow();
  }
});
